<?php
session_start();
include 'conexao.php';

if(!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo']!=='restaurante'){
    exit('Acesso negado');
}

$id = $_GET['id'] ?? null;
$restaurante_id = $_SESSION['usuario_id'];

if($id){
    $stmt = $conn->prepare("DELETE FROM cardapio WHERE id=? AND restaurante_id=?");
    $stmt->execute([$id,$restaurante_id]);
    header('Location: cardapio.php');
}
