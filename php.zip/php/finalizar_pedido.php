<?php
session_start();
include 'conexao.php';

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] !== 'cliente') {
    exit("⚠️ Apenas clientes podem finalizar pedidos.");
}

if (empty($data['carrinho'])) {
    exit("⚠️ Carrinho vazio.");
}

$carrinho = $data['carrinho'];
$cliente_id = $_SESSION['usuario_id'];
$restaurante_id = $data['restaurante_id'];
$pagamento = $data['pagamento'] ?? '';
$tipoPedido = $data['tipoPedido'] ?? '';
$endereco = $data['endereco_entrega'] ?? '';
$mesa = $data['mesa'] ?? '';
$obsMesa = $data['obsMesa'] ?? '';
$total = 0;

foreach ($carrinho as $item) {
    $total += $item['preco'] * $item['qtd'];
}

/* === VALIDAÇÕES === */
if ($tipoPedido === 'entrega' && !in_array($pagamento, ['pix', 'debito', 'credito'])) {
    exit("❌ Forma de pagamento inválida.");
}
if ($tipoPedido === 'entrega' && empty($endereco)) {
    exit("❌ Endereço não informado.");
}
if ($tipoPedido === 'local' && empty($mesa)) {
    exit("❌ Número da mesa não informado.");
}

/* === SALVAR PEDIDO NO BANCO === */
try {
    $conn->beginTransaction();

    $stmt = $conn->prepare("INSERT INTO pedidos 
        (cliente_id, restaurante_id, total, status, pagamento, tipo, endereco, mesa, observacao)
        VALUES (?, ?, ?, 'pendente', ?, ?, ?, ?, ?)");
    $stmt->execute([$cliente_id, $restaurante_id, $total, $pagamento, $tipoPedido, $endereco, $mesa, $obsMesa]);
    $pedido_id = $conn->lastInsertId();

    $stmtItem = $conn->prepare("INSERT INTO pedido_itens (pedido_id, cardapio_id, qtd, preco, observacao) 
                                VALUES (?, ?, ?, ?, ?)");
    foreach ($carrinho as $item) {
        $stmtItem->execute([$pedido_id, $item['id'], $item['qtd'], $item['preco'], $item['obs']]);
    }

    $conn->commit();
} catch (Exception $e) {
    $conn->rollBack();
    exit("Erro ao salvar pedido: " . $e->getMessage());
}

/* === CASO: PEDIDO NO LOCAL === */
if ($tipoPedido === 'local') {
    echo "PEDIDO_ENVIADO_OK";
    exit;
}

/* === CASO: PAGAMENTO PIX === */
if ($pagamento === 'pix') {
    $stmt = $conn->prepare("SELECT pix_chave FROM usuarios WHERE id = ? AND tipo = 'restaurante'");
    $stmt->execute([$restaurante_id]);
    $pix_chave = $stmt->fetchColumn();

    if (!$pix_chave) {
        exit("❌ Restaurante não tem chave PIX cadastrada.");
    }

    $total_float = number_format($total, 2, '.', '');
    $pix_payload = "00020126360014BR.GOV.BCB.PIX0114{$pix_chave}520400005303986540{$total_float}5802BR5920Restaurante6009SAO PAULO62070503***6304ABCD";
    $qr_url = "https://api.qrserver.com/v1/create-qr-code/?data=".urlencode($pix_payload)."&size=180x180";

    echo "<!doctype html>
<html lang='pt-BR'>
<head>
<meta charset='utf-8'>
<title>Pedido Finalizado</title>
<link rel='stylesheet' href='../css/cliente.css'>
</head>
<body>
  <h2>🎉 Pedido realizado com sucesso!</h2>
  <p>Número do pedido: <strong>#{$pedido_id}</strong></p>
  <p>Total: <strong>R$ ".number_format($total,2,',','.')."</strong></p>
  <p>Forma de pagamento: <strong>PIX</strong></p>
  <p>📲 Escaneie o QR Code abaixo para pagar:</p>
  <img src='{$qr_url}' alt='QR Code PIX'>
  <a href='restaurantes.php' class='btn'>Fazer novo pedido</a>
</body>
</html>";
    exit;
}

/* === CASO: PAGAMENTO DÉBITO / CRÉDITO === */
if (in_array($pagamento, ['debito', 'credito'])) {
    echo "<!doctype html>
<html lang='pt-BR'>
<head>
<meta charset='utf-8'>
<title>Pedido Finalizado</title>
<link rel='stylesheet' href='../css/cliente.css'>
</head>
<body>
  <h2>🎉 Pedido realizado com sucesso!</h2>
  <p>Número do pedido: <strong>#{$pedido_id}</strong></p>
  <p>Total: <strong>R$ ".number_format($total,2,',','.')."</strong></p>
  <p>Forma de pagamento: <strong>".ucfirst($pagamento)."</strong></p>
  <p>💳 O pagamento será efetuado na entrega via maquininha.</p>
  <a href='restaurantes.php' class='btn'>Fazer novo pedido</a>
</body>
</html>";
    exit;
}
?>
