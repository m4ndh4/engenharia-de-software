<?php
session_start();
include 'conexao.php';

if(!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo']!=='restaurante'){
    exit('Acesso negado');
}

$restaurante_id = $_SESSION['usuario_id'];
$id        = $_POST['id'] ?? null;
$nome      = $_POST['nome'] ?? '';
$descricao = $_POST['descricao'] ?? '';
$preco     = $_POST['preco'] ?? 0.00;
$tipo      = $_POST['tipo'] ?? 'comida';

// Upload da imagem
$imagemNome = '';
if(isset($_FILES['imagem']) && $_FILES['imagem']['error']==0){
    $ext = pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION);
    $imagemNome = uniqid().'.'.$ext;
    move_uploaded_file($_FILES['imagem']['tmp_name'], '../uploads/'.$imagemNome);
}

if($id){ // Editar
    if($imagemNome){
        $stmt = $conn->prepare("UPDATE cardapio 
                                SET nome=?, descricao=?, preco=?, tipo=?, imagem=? 
                                WHERE id=? AND restaurante_id=?");
        $stmt->execute([$nome,$descricao,$preco,$tipo,$imagemNome,$id,$restaurante_id]);
    }else{
        $stmt = $conn->prepare("UPDATE cardapio 
                                SET nome=?, descricao=?, preco=?, tipo=? 
                                WHERE id=? AND restaurante_id=?");
        $stmt->execute([$nome,$descricao,$preco,$tipo,$id,$restaurante_id]);
    }
    echo "OK! Item atualizado.";
}else{ // Novo
    $stmt = $conn->prepare("INSERT INTO cardapio (restaurante_id,nome,descricao,preco,tipo,imagem) 
                            VALUES (?,?,?,?,?,?)");
    $stmt->execute([$restaurante_id,$nome,$descricao,$preco,$tipo,$imagemNome]);
    echo "OK! Item adicionado.";
}
