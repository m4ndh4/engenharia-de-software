// Navegação mobile
const navSlide = () => {
    const burger = document.querySelector('.burger');
    const nav = document.querySelector('.nav-links');
    const navLinks = document.querySelectorAll('.nav-links li');
    
    burger.addEventListener('click', () => {
        // Alternar navegação
        nav.classList.toggle('nav-active');
        
        // Animar links
        navLinks.forEach((link, index) => {
            if (link.style.animation) {
                link.style.animation = '';
            } else {
                link.style.animation = `navLinkFade 0.5s ease forwards ${index / 7 + 0.3}s`;
            }
        });
        
        // Animação do burger
        burger.classList.toggle('toggle');
    });
}

// Scroll suave para âncoras
const smoothScroll = () => {
    const links = document.querySelectorAll('a[href^="#"]');
    
    for (const link of links) {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const href = this.getAttribute('href');
            
            if (href === "#") return;
            
            const targetElement = document.querySelector(href);
            if (targetElement) {
                const topOffset = 80; // Altura do header fixo
                const elementPosition = targetElement.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - topOffset;
                
                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    }
}

// Validação do formulário
const validateForm = () => {
    const form = document.getElementById('contact-form');
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        let isValid = true;
        const name = document.getElementById('name');
        const email = document.getElementById('email');
        const message = document.getElementById('message');
        
        // Validar nome
        if (name.value.trim() === '') {
            isValid = false;
            highlightError(name);
        } else {
            removeHighlight(name);
        }
        
        // Validar email
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email.value)) {
            isValid = false;
            highlightError(email);
        } else {
            removeHighlight(email);
        }
        
        // Validar mensagem
        if (message.value.trim() === '') {
            isValid = false;
            highlightError(message);
        } else {
            removeHighlight(message);
        }
        
        if (isValid) {
            // Enviar formulário (aqui seria a submissão AJAX em um caso real)
            this.submit();
        }
    });
}

function highlightError(element) {
    element.style.borderColor = '#e74c3c';
    element.style.boxShadow = '0 0 0 2px rgba(231, 76, 60, 0.2)';
}

function removeHighlight(element) {
    element.style.borderColor = '#ddd';
    element.style.boxShadow = 'none';
}

// Animação de revelação ao scroll
const revealOnScroll = () => {
    const elements = document.querySelectorAll('.feature-card');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = 1;
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, {
        threshold: 0.1
    });
    
    elements.forEach(element => {
        element.style.opacity = 0;
        element.style.transform = 'translateY(20px)';
        element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(element);
    });
}

// Inicializar todas as funcionalidades quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    navSlide();
    smoothScroll();
    validateForm();
    revealOnScroll();
});