function atualizarStatus(id, status) {
  fetch("atualizar_status.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id, status })
  }).then(r => r.text()).then(resp => {
    if (resp !== "OK") alert("Erro ao atualizar status");
  });
}

function abrirAdicionarItem(pedidoId) {
  document.getElementById("pedidoId").value = pedidoId;
  document.getElementById("modalAdicionarItem").style.display = "flex";
}

function fecharModal() {
  document.getElementById("modalAdicionarItem").style.display = "none";
}

function adicionarItemMesa() {
  const pedido = document.getElementById("pedidoId").value;
  const item = document.getElementById("itemSelect").value;
  const qtd = document.getElementById("itemQtd").value;

  fetch("adicionar_item.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ pedido, item, qtd })
  }).then(r => r.text()).then(resp => {
    if (resp === "OK") {
      alert("Item adicionado com sucesso!");
      fecharModal();
      location.reload();
    } else {
      alert("Erro ao adicionar item.");
    }
  });
}



