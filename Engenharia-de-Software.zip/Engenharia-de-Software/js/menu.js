let carrinho = [];

// Filtro de produtos
document.querySelectorAll('.filtro').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.filtro').forEach(b => b.classList.remove('ativo'));
    btn.classList.add('ativo');
    const tipo = btn.dataset.tipo;

    document.querySelectorAll('.produto').forEach(p => {
      if (tipo === 'todos' || p.dataset.tipo === tipo) p.style.display = 'block';
      else p.style.display = 'none';
    });
  });
});

// Expansão de produto
document.querySelectorAll('.btn-detalhes').forEach(btn => {
  btn.addEventListener('click', e => {
    const produto = e.target.closest('.produto');
    produto.classList.toggle('expanded');
    btn.textContent = produto.classList.contains('expanded') ? 'Ver menos' : 'Ver mais';
  });
});

// Adicionar ao carrinho
document.querySelectorAll('.btn-add').forEach(btn => {
  btn.addEventListener('click', e => {
    const p = e.target.closest('.produto');
    const id = p.dataset.id;
    const nome = p.dataset.nome;
    const preco = parseFloat(p.dataset.preco);

    const existente = carrinho.find(i => i.id === id);
    if (existente) existente.qtd++;
    else carrinho.push({ id, nome, preco, qtd: 1 });

    renderCarrinho();
  });
});

// Render carrinho
function renderCarrinho() {
  const box = document.getElementById('itens-carrinho');
  box.innerHTML = '';
  carrinho.forEach((item, i) => {
    const div = document.createElement('div');
    div.className = 'item-carrinho';
    div.innerHTML = `
      <p><strong>${item.nome}</strong></p>
      <p>Qtd: ${item.qtd} | R$ ${(item.preco * item.qtd).toFixed(2).replace('.', ',')}</p>
    `;
    box.appendChild(div);
  });
}

// Alterna entrega/mesa
document.querySelectorAll('input[name="tipo"]').forEach(radio => {
  radio.addEventListener('change', () => {
    const tipo = document.querySelector('input[name="tipo"]:checked').value;
    document.querySelector('.endereco-box').style.display = tipo === 'Entrega' ? 'block' : 'none';
    document.querySelector('.mesa-box').style.display = tipo === 'Mesa' ? 'block' : 'none';
  });
});

// Limpar carrinho
document.getElementById('limpar').addEventListener('click', () => {
  carrinho = [];
  renderCarrinho();
});

// Finalizar pedido
document.getElementById('finalizar').addEventListener('click', () => {
  if (carrinho.length === 0) {
    alert("Adicione itens ao carrinho!");
    return;
  }

  const tipo = document.querySelector('input[name="tipo"]:checked').value;
  const endereco = document.getElementById('endereco').value.trim();
  const mesa = document.getElementById('numeroMesa').value.trim();
  const obsMesa = document.getElementById('observacaoMesa').value.trim();

  fetch('salvar_pedido.php', {
    method: 'POST',
    body: new URLSearchParams({
      restaurante_id: RESTAURANTE_ID,
      cliente_id: CLIENTE_ID,
      tipo,
      endereco,
      mesa,
      obsMesa,
      itens: JSON.stringify(carrinho)
    })
  })
  .then(r => r.text())
  .then(t => {
    alert(t);
    if (t.includes("OK")) {
      carrinho = [];
      renderCarrinho();
    }
  });
});
