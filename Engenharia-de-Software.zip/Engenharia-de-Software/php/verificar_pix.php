<?php
// verificar_pix.php
$chave = $_GET['chave'] ?? '';
$nome = $_GET['nome'] ?? '';

// Aqui você poderia buscar no seu banco
// Por enquanto, vamos apenas simular que "123.456.789-09" pertence a "João Silva"
$mock = [
    '123.456.789-09' => 'João Silva',
    '11122233344' => 'Maria Oliveira',
];

if(isset($mock[$chave]) && $mock[$chave] === $nome){
    $verificado = true;
} else {
    $verificado = false;
}

echo json_encode(['verificado' => $verificado]);
