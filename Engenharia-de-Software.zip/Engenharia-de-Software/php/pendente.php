<h2>⏳ Pagamento pendente!</h2>
<p>Estamos aguardando a confirmação do Mercado Pago.</p>
<a href="perfil.php">Ir para o perfil</a>
