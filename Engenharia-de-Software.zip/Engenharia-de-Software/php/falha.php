<h2>❌ Pagamento falhou!</h2>
<p>Tente novamente ou use outro método de pagamento.</p>
<a href="checkout.php">Voltar ao checkout</a>
