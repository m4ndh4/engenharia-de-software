<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] !== 'restaurante') {
    header("Location: login.php");
    exit;
}

include 'conexao.php';
$restaurante_id = $_SESSION['usuario_id'];

// Busca os pedidos do restaurante
$stmt = $conn->prepare("
    SELECT 
        p.id, 
        p.tipo AS tipo_pedido, 
        p.mesa, 
        p.endereco, 
        p.status, 
        p.pagamento AS forma_pagamento, 
        p.criado_em,
        c.nome AS cliente_nome
    FROM pedidos p
    JOIN usuarios c ON p.cliente_id = c.id
    WHERE p.restaurante_id = :rest
    ORDER BY p.criado_em DESC
");
$stmt->execute([':rest' => $restaurante_id]);
$pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Itens de cada pedido
$itensStmt = $conn->prepare("
    SELECT i.*, c.nome AS nome_item
    FROM pedido_itens i
    JOIN cardapio c ON i.cardapio_id = c.id
    WHERE i.pedido_id = :pedido
");
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Painel de Pedidos</title>
<link rel="stylesheet" href="../css/painel_pedidos.css">
</head>
<body>

<header class="topo">
  <h1>📦 Painel de Pedidos</h1>
</header>

<div class="container">
  <?php if (empty($pedidos)): ?>
    <p class="sem-pedidos">Nenhum pedido recebido ainda.</p>
  <?php else: ?>
    <?php foreach ($pedidos as $pedido): ?>
      <div class="pedido-card" id="pedido-<?= $pedido['id'] ?>">
        <h2>Pedido #<?= $pedido['id'] ?> — <?= htmlspecialchars($pedido['tipo_pedido'] === 'local' ? "Mesa {$pedido['mesa']}" : "Entrega") ?></h2>
        <p><strong>Cliente:</strong> <?= htmlspecialchars($pedido['cliente_nome']) ?></p>
        <p><strong>Forma de pagamento:</strong> <?= htmlspecialchars(ucfirst($pedido['forma_pagamento'])) ?></p>

        <?php if ($pedido['tipo_pedido'] === 'entrega'): ?>
          <p><strong>Endereço:</strong> <?= htmlspecialchars($pedido['endereco']) ?></p>
        <?php endif; ?>

        <p><strong>Status:</strong> 
          <select onchange="atualizarStatus(<?= $pedido['id'] ?>, this.value)">
            <?php
              $statusOptions = ['Recebido', 'Em preparo', 'Pronto', 'Entregue'];
              foreach ($statusOptions as $status) {
                $selected = ($pedido['status'] === $status) ? 'selected' : '';
                echo "<option value='$status' $selected>$status</option>";
              }
            ?>
          </select>
        </p>

        <h3>Itens:</h3>
        <ul>
          <?php
          $itensStmt->execute([':pedido' => $pedido['id']]);
          foreach ($itensStmt as $item):
          ?>
            <li><?= htmlspecialchars($item['nome_item']) ?> x<?= $item['qtd'] ?> — R$ <?= number_format($item['preco'], 2, ',', '.') ?></li>
          <?php endforeach; ?>
        </ul>

        <?php if ($pedido['tipo_pedido'] === 'local'): ?>
          <button onclick="abrirAdicionarItem(<?= $pedido['id'] ?>)">➕ Adicionar item à mesa</button>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<!-- Modal adicionar item -->
<div id="modalAdicionarItem" class="modal-bg">
  <div class="modal">
    <h3>Adicionar item à mesa</h3>
    <input type="hidden" id="pedidoId">
    <label>Item:</label>
    <select id="itemSelect">
      <?php
      $itens = $conn->prepare("SELECT id, nome FROM cardapio WHERE restaurante_id = :r");
      $itens->execute([':r' => $restaurante_id]);
      foreach ($itens as $i) {
        echo "<option value='{$i['id']}'>{$i['nome']}</option>";
      }
      ?>
    </select>
    <label>Quantidade:</label>
    <input type="number" id="itemQtd" min="1" value="1">
    <button onclick="adicionarItemMesa()">Adicionar</button>
    <button onclick="fecharModal()">Fechar</button>
  </div>
</div>

<script src="../js/painel_pedidos.js"></script>
</body>
</html>
