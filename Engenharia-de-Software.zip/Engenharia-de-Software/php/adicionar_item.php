<?php
include 'conexao.php';
$data = json_decode(file_get_contents("php://input"), true);

$pedido = $data['pedido'] ?? null;
$item = $data['item'] ?? null;
$qtd = $data['qtd'] ?? 1;

if ($pedido && $item) {
    $stmt = $conn->prepare("SELECT preco FROM cardapio WHERE id = :i");
    $stmt->execute([':i' => $item]);
    $preco = $stmt->fetchColumn();

    $ins = $conn->prepare("INSERT INTO pedido_itens (pedido_id, item_id, quantidade, preco) VALUES (:p, :i, :q, :pr)");
    $ins->execute([':p' => $pedido, ':i' => $item, ':q' => $qtd, ':pr' => $preco]);
    echo "OK";
} else {
    http_response_code(400);
    echo "Erro";
}
