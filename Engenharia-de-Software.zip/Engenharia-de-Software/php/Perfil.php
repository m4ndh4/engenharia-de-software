<?php
session_start();
include 'conexao.php';

if (!isset($_SESSION['usuario_id'])) {
    header('Location: php/Login.php');
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$stmt = $conn->prepare("SELECT nome, email, tipo, telefone, endereco, cpf_cnpj_tipo, cpf_cnpj, nome_proprietario, logotipo, pix_chave, horario_funcionamento, descricao 
                        FROM usuarios WHERE id = :id");
$stmt->bindParam(':id', $usuario_id, PDO::PARAM_INT);
$stmt->execute();
$usuario = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="../css/perfil.css">
<title>Perfil — CardapiOn</title>
<style>
.img-wrapper {
  position: relative;
  width: 120px;
  height: 120px;
}
.img-wrapper img {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid #ccc;
}
.change-photo-btn {
  position: absolute;
  bottom: 0;
  right: 0;
  background: rgba(0,0,0,0.6);
  color: #fff;
  padding: 4px 8px;
  font-size: 12px;
  border-radius: 12px;
  cursor: pointer;
  display: none; /* só aparece no modo edição */
}
input#logoInput {
  display: none;
}
textarea {
  width: 100%;
  min-height: 70px;
  resize: vertical;
  border-radius: 8px;
  padding: 8px;
  border: 1px solid #ccc;
  font-family: inherit;
}
textarea:disabled, input:disabled, select:disabled {
  background-color: #f5f5f5;
  color: #555;
}
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

<div class="perfil-page">
  <div class="perfil-box">

  <a href="index.php"><i class="fa-solid fa-home"></i></a>

    <div class="perfil-header">
      <div class="img-wrapper">
        <img id="previewLogo" src="<?= !empty($usuario['logotipo']) ? '../uploads/' . htmlspecialchars($usuario['logotipo']) : '../img/perfilDefault.png' ?>" alt="Foto de Perfil">
        <div class="change-photo-btn" id="changePhotoBtn">Alterar Foto</div>
        <input type="file" name="logotipo" id="logoInput" accept="image/*">
      </div>
      <h2><?= htmlspecialchars($usuario['nome'] ?? '') ?></h2>
    </div>

    <div class="perfil-layout">
      <div class="perfil-info">
        <form id="perfilForm" enctype="multipart/form-data">
          <div class="form-grid">
            <div class="form-row">
              <label>Nome:</label>
              <input type="text" name="nome" value="<?= htmlspecialchars($usuario['nome'] ?? '') ?>" disabled>
            </div>

            <div class="form-row">
              <label>E-mail:</label>
              <input type="email" name="email" value="<?= htmlspecialchars($usuario['email'] ?? '') ?>" disabled>
            </div>

            <div class="form-row">
              <label>Tipo de conta:</label>
              <input type="text" name="tipo" value="<?= htmlspecialchars($usuario['tipo'] ?? '') ?>" disabled>
            </div>

            <?php if (($usuario['tipo'] ?? '') === 'restaurante'): ?>
              <div class="form-row">
                <label>Documento:</label>
                <select name="cpf_cnpj_tipo" disabled>
                  <option value="cpf" <?= ($usuario['cpf_cnpj_tipo'] ?? '') === 'cpf' ? 'selected' : '' ?>>CPF</option>
                  <option value="cnpj" <?= ($usuario['cpf_cnpj_tipo'] ?? '') === 'cnpj' ? 'selected' : '' ?>>CNPJ</option>
                </select>
              </div>

              <div class="form-row">
                <label>Número (CPF/CNPJ):</label>
                <input type="text" name="cpf_cnpj" value="<?= htmlspecialchars($usuario['cpf_cnpj'] ?? '') ?>" disabled>
              </div>

              <div class="form-row">
                <label>Nome do Proprietário:</label>
                <input type="text" name="nome_proprietario" value="<?= htmlspecialchars($usuario['nome_proprietario'] ?? '') ?>" disabled>
              </div>

              <div class="form-row">
                <label>Telefone:</label>
                <input type="text" name="telefone" value="<?= htmlspecialchars($usuario['telefone'] ?? '') ?>" disabled>
              </div>

              <div class="form-row">
                <label>Endereço:</label>
                <input type="text" name="endereco" value="<?= htmlspecialchars($usuario['endereco'] ?? '') ?>" disabled>
              </div>

              <div class="form-row">
                <label>Descrição do Restaurante:</label>
                <textarea name="descricao" placeholder="Fale um pouco sobre seu restaurante..." disabled><?= htmlspecialchars($usuario['descricao'] ?? '') ?></textarea>
              </div>

              <div class="form-row">
                <label>Chave PIX:</label>
                <input type="text" name="pix_chave" value="<?= htmlspecialchars($usuario['pix_chave'] ?? '') ?>" disabled>
              </div>

              <div class="horario-box">
                <h3>🕒 Horário de Funcionamento</h3>
                <?php
                $dias = ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'];
                $salvos = json_decode($usuario['horario_funcionamento'] ?? '{}', true) ?: [];
                foreach ($dias as $dia): ?>
                  <div class="horario-dia">
                    <label><?= $dia ?>:</label>
                    <input type="text" name="horario_funcionamento[<?= $dia ?>]" placeholder="Ex: 08:00 - 18:00 ou Fechado" value="<?= htmlspecialchars($salvos[$dia] ?? '') ?>" disabled>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>

          <div class="botoes">
            <a href="logout.php" class="btn">Sair</a>
            <button type="button" id="editBtn" class="btn">Editar</button>
            <button type="button" id="deleteBtn" class="btn btn-danger">Excluir Conta</button>
          </div>
        </form>
      </div>

      <?php if (($usuario['tipo'] ?? '') === 'restaurante'): ?>
        <div class="perfil-side">
          <div class="cardapio-box">
            <h2>📖 Cardápio</h2>
            <a href="cardapio.php">
              <p>Gerencie seus pratos e bebidas.</p>
              <h3>Ir para Cardápio</h3>
            </a>
          </div>

          <div class="cardapio-box">
            <h2>🧾 Pedidos</h2>
            <a href="painel_pedidos.php">
              <p>Acompanhe e atualize pedidos em tempo real.</p>
              <h3>Ir para Painel</h3>
            </a>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
const editBtn = document.getElementById('editBtn');
const deleteBtn = document.getElementById('deleteBtn');
const form = document.getElementById('perfilForm');
const logoInput = document.getElementById('logoInput');
const previewLogo = document.getElementById('previewLogo');
const changePhotoBtn = document.getElementById('changePhotoBtn');
let editMode = false;

editBtn.addEventListener('click', () => {
  const inputs = form.querySelectorAll('input, select, textarea');
  if (!editMode) {
    // Entrando em modo edição
    inputs.forEach(i => i.disabled = false);
    changePhotoBtn.style.display = 'block';
    editBtn.textContent = 'Salvar';
    editMode = true;
  } else {
    // Salvando as alterações
    const formData = new FormData(form);
    if (logoInput.files[0]) formData.append('logotipo', logoInput.files[0]);

    fetch('perfil_salvar.php', { method: 'POST', body: formData })
    .then(r => r.text())
    .then(t => {
      alert(t);
      if (t.includes('OK')) {
        inputs.forEach(i => i.disabled = true);
        changePhotoBtn.style.display = 'none';
        editBtn.textContent = 'Editar';
        editMode = false;
      }
    })
    .catch(err => alert('❌ Erro ao salvar: ' + err));
  }
});

changePhotoBtn.addEventListener('click', () => logoInput.click());

logoInput.addEventListener('change', e => {
  const file = e.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = e => previewLogo.src = e.target.result;
    reader.readAsDataURL(file);
  }
});

deleteBtn.addEventListener('click', () => {
  if (confirm("⚠️ Deseja excluir sua conta permanentemente?")) {
    fetch('perfil_excluir.php', { method: 'POST' })
    .then(r => r.text())
    .then(t => {
      alert(t);
      if (t.includes('OK')) window.location.href = "Cadastro.php";
    });
  }
});
</script>
</body>
</html>
