<?php
session_start();
if(isset($_SESSION['usuario_id'])){
    header('Location: index.php'); // já logado, redireciona para home
    exit;
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<link rel="stylesheet" href="../css/login.css">
<title>Login — CardapiOn</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/izitoast/dist/css/iziToast.min.css">
</head>
<body>

<main style="max-width:400px;margin:80px auto;padding:60px;border:1px solid #ccc;border-radius:12px;">
    <h2>Entrar</h2>
    <form id="loginForm">
        <div class="form-row">
            <label for="email">E-mail</label>
            <input id="email" name="email" type="email" required />
        </div>
        <div class="form-row">
            <label for="password">Senha</label>
            <input id="password" name="password" type="password" required />
        </div>
        <div style="margin-top:12px">
            <button type="submit" class="btn">Entrar</button>
        </div>
    </form>
    <p style="margin-top:12px">
        Não tem conta? <a href="cadastro.php">Cadastre-se aqui</a>
    </p>
</main>

<script>
document.getElementById('loginForm').addEventListener('submit', function(e){
    e.preventDefault();
    const form = new FormData(this);
    fetch('auth.php', { method:'POST', body: form })
    .then(r=>r.text())
    .then(txt=>{
        alert(txt);
        if(txt.includes('OK')) {
            const parts = txt.split('|');
            const tipo = parts[1] ? parts[1].trim() : '';

            if(tipo === 'cliente'){
                window.location.href = 'Perfil.php';
            } else {
                window.location.href = 'Perfil.php'; // restaurante
            }
        }
    })
    .catch(()=> iziToast.info({
        title: "Erro!",
        message: "Email ou senha incorretos",
        timeout: 5000,
        position: 'topRight',
    }));
});



</script>
<script src="https://cdn.jsdelivr.net/npm/izitoast/dist/js/iziToast.min.js"></script>

</body>
</html>
