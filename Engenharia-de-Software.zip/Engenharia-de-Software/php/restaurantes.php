<?php
session_start();
include 'conexao.php';

// Busca restaurantes
$stmt = $conn->query("SELECT id, nome FROM usuarios WHERE tipo='restaurante'");
$restaurantes = $stmt->fetchAll();
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>Restaurantes Disponíveis</title>
  <link rel="stylesheet" href="../css/cliente.css">
</head>
<body>
<h2>Restaurantes</h2>
<ul>
  <?php foreach($restaurantes as $r): ?>
    <li>
      <a href="cardapio_cliente.php?id=<?= $r['id'] ?>">
        <?= htmlspecialchars($r['nome']) ?>
      </a>
    </li>
  <?php endforeach; ?>
</ul>
</body>
</html>
