<?php
session_start();
include 'conexao.php';

// Verifica se é restaurante
if(!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] !== 'restaurante'){
    header('Location: ../index.php');
    exit;
}

$restaurante_id = $_SESSION['usuario_id'];

// Busca todos os pratos do restaurante
$sql = "SELECT * FROM cardapio WHERE restaurante_id = :rid";
$stmt = $conn->prepare($sql);
$stmt->bindParam(':rid', $restaurante_id, PDO::PARAM_INT);
$stmt->execute();
$pratos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="../css/cardapio.css">
<title>Cardápio — Restaurante</title>
</head>
<body>


<h2>Cardápio</h2>
<div class="cardapio-header">
    <button class="btn" id="novoPratoBtn">Adicionar Prato</button>
</div>

<!-- Filtro -->
<div class="form-row">
  <label for="filtroTipo">Tipo:</label>
  <select name="filtroTipo" id="filtroTipo">
    <option value="todos">Todos</option>
    <option value="comida">Comida</option>
    <option value="bebida">Bebida</option>
  </select>
</div>

<div class="grid-pratos">
    <?php foreach($pratos as $prato): ?>
    <div class="prato-card" data-tipo="<?= htmlspecialchars($prato['tipo']) ?>">
        <?php if(!empty($prato['imagem'])): ?>
        <img src="../uploads/<?= htmlspecialchars($prato['imagem']) ?>" alt="<?= htmlspecialchars($prato['nome']) ?>">
        <?php endif; ?>
        <h3><?= htmlspecialchars($prato['nome']) ?></h3>
        <p><?= htmlspecialchars($prato['descricao']) ?></p>
        <p><strong>R$ <?= number_format($prato['preco'],2,',','.') ?></strong></p>
        <p><em><?= ucfirst($prato['tipo']) ?></em></p>
        <div class="acoes">
            <button class="btn editarBtn" 
                    data-id="<?= $prato['id'] ?>" 
                    data-nome="<?= htmlspecialchars($prato['nome']) ?>"
                    data-descricao="<?= htmlspecialchars($prato['descricao']) ?>"
                    data-preco="<?= $prato['preco'] ?>"
                    data-tipo="<?= $prato['tipo'] ?>"
                    >Editar</button>
            <button class="btn btn-red" onclick="if(confirm('Deseja realmente excluir?')) location.href='cardapio_deletar.php?id=<?= $prato['id'] ?>'">Excluir</button>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Modal Formulário -->
<div class="modal" id="modalForm">
    <div class="modal-content">
        <span id="fecharModal">&times;</span>
        <h3 id="modalTitle">Novo Prato</h3>
        <form id="pratoForm" enctype="multipart/form-data">
            <input type="hidden" name="id" id="pratoId">
            <div class="form-row">
                <label>Nome</label>
                <input type="text" name="nome" id="nome" required>
            </div>
            <div class="form-row">
                <label>Descrição</label>
                <textarea name="descricao" id="descricao"></textarea>
            </div>
            <div class="form-row">
                <label>Preço</label>
                <input type="number" step="0.01" name="preco" id="preco" required>
            </div>
            <div class="form-row">
                <label>Tipo</label>
                <select name="tipo" id="tipo" required>
                    <option value="comida">Comida</option>
                    <option value="bebida">Bebida</option>
                </select>
            </div>
            <div class="form-row">
                <label>Imagem</label>
                <input type="file" name="imagem" id="imagem" accept="image/*">
            </div>
            <button type="submit" class="btn">Salvar</button>
        </form>
    </div>
</div>

<script>
// Modal
const modal = document.getElementById('modalForm');
const btnNovo = document.getElementById('novoPratoBtn');
const spanFechar = document.getElementById('fecharModal');

btnNovo.onclick = () => {
    document.getElementById('modalTitle').textContent = 'Novo Prato';
    document.getElementById('pratoForm').reset();
    document.getElementById('pratoId').value = '';
    modal.style.display = 'flex';
}

spanFechar.onclick = () => modal.style.display = 'none';
window.onclick = (e) => { if(e.target==modal) modal.style.display='none'; }

// Editar prato
document.querySelectorAll('.editarBtn').forEach(btn=>{
    btn.addEventListener('click', ()=>{
        document.getElementById('modalTitle').textContent = 'Editar Prato';
        document.getElementById('pratoId').value = btn.dataset.id;
        document.getElementById('nome').value = btn.dataset.nome;
        document.getElementById('descricao').value = btn.dataset.descricao;
        document.getElementById('preco').value = btn.dataset.preco;
        document.getElementById('tipo').value = btn.dataset.tipo;
        modal.style.display = 'flex';
    });
});

// Enviar formulário
document.getElementById('pratoForm').addEventListener('submit', function(e){
    e.preventDefault();
    const form = new FormData(this);
    fetch('cardapio_salvar.php', {method:'POST', body:form})
    .then(r=>r.text())
    .then(txt=>{
        alert(txt);
        if(txt.includes('OK')) location.reload();
    })
    .catch(()=>alert('Erro ao salvar prato.'));
});

// Filtro de pratos
const filtroSelect = document.getElementById('filtroTipo');

filtroSelect.addEventListener('change', function(){
    const valor = this.value;
    document.querySelectorAll('.prato-card').forEach(card => {
        if(valor==='todos' || card.dataset.tipo === valor){
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
});
</script>

</body>
</html>
