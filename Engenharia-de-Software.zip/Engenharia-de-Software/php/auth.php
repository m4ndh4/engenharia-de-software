<?php
// auth.php
session_start();
include 'conexao.php';

$action = $_GET['action'] ?? 'login';

if ($action === 'signup') {
    // ---------- CADASTRO ----------
    $nome     = $_POST['name'] ?? '';
    $email    = $_POST['email'] ?? '';
    $senha    = $_POST['password'] ?? '';
    $tipo     = $_POST['tipo'] ?? 'cliente'; // cliente ou restaurante
    $telefone = $_POST['telefone'] ?? null;
    $endereco = $_POST['endereco'] ?? null;
    $cnpj     = $_POST['cnpj'] ?? null;

    if (!$nome || !$email || !$senha) {
        echo "⚠️ Preencha todos os campos obrigatórios!";
        exit;
    }

    // Verifica duplicidade
    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->rowCount() > 0) {
        echo "⚠️ E-mail já cadastrado!";
        exit;
    }

    // Criptografa senha
    $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

    // Upload de logotipo (se for restaurante)
    $logotipo = null;
    if ($tipo === 'restaurante' && !empty($_FILES['logotipo']['name'])) {
        $targetDir = "../uploads/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

        $filename = uniqid()."_".basename($_FILES['logotipo']['name']);
        $targetFile = $targetDir.$filename;

        if (move_uploaded_file($_FILES['logotipo']['tmp_name'], $targetFile)) {
            $logotipo = $filename;
        }
    }

    // Insere usuário no banco
    $stmt = $conn->prepare("
        INSERT INTO usuarios (nome, email, senha, tipo, telefone, endereco, cnpj, logotipo) 
        VALUES (:nome, :email, :senha, :tipo, :telefone, :endereco, :cnpj, :logotipo)
    ");
    
    $ok = $stmt->execute([
        ':nome'     => $nome,
        ':email'    => $email,
        ':senha'    => $senhaHash,
        ':tipo'     => $tipo,
        ':telefone' => $telefone,
        ':endereco' => $endereco,
        ':cnpj'     => $cnpj,
        ':logotipo' => $logotipo
    ]);

    if ($ok) {
        $_SESSION['usuario_id']   = $conn->lastInsertId();
        $_SESSION['usuario_nome'] = $nome;
        $_SESSION['usuario_tipo'] = $tipo;
        echo "OK|$tipo";
    } else {
        echo "❌ Erro ao cadastrar usuário.";
    }

} else {
    // ---------- LOGIN ----------
    $email = $_POST['email'] ?? '';
    $senha = $_POST['password'] ?? '';

    if (!$email || !$senha) {
        echo "⚠️ Preencha todos os campos!";
        exit;
    }

    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($senha, $user['senha'])) {
        $_SESSION['usuario_id']   = $user['id'];
        $_SESSION['usuario_nome'] = $user['nome'];
        $_SESSION['usuario_tipo'] = $user['tipo'];

        // Resposta no formato OK|tipo
        echo "OK|{$user['tipo']}";
    } else {
        echo "⚠️ E-mail ou senha incorretos!";
    }
}

if ($_POST['tipo'] === 'restaurante') {
    $cnpj = preg_replace('/\D/', '', $_POST['cnpj']);
    $check = @file_get_contents("https://publica.cnpj.ws/cnpj/$cnpj");
    $data = json_decode($check, true);

    if (!isset($data['razao_social']) || $data['estabelecimento']['situacao_cadastral'] !== 'ATIVA') {
        echo "CNPJ inválido ou inativo.";
        exit;
    }
}
