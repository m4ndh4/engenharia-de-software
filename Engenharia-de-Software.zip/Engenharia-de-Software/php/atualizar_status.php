<?php
include 'conexao.php';
$data = json_decode(file_get_contents("php://input"), true);
$id = $data['id'] ?? null;
$status = $data['status'] ?? '';

if ($id && $status) {
    $stmt = $conn->prepare("UPDATE pedidos SET status = :s WHERE id = :i");
    $stmt->execute([':s' => $status, ':i' => $id]);
    echo "OK";
} else {
    http_response_code(400);
    echo "Erro";
}
