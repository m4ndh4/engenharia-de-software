-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 30/10/2025 às 11:26
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `cardapion`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `cardapio`
--

CREATE TABLE `cardapio` (
  `id` int(11) NOT NULL,
  `restaurante_id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` text DEFAULT NULL,
  `preco` decimal(10,2) NOT NULL,
  `tipo` enum('comida','bebida') NOT NULL,
  `imagem` varchar(255) DEFAULT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  `atualizado_em` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `categoria` enum('comida','bebida') DEFAULT 'comida'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `cardapio`
--

INSERT INTO `cardapio` (`id`, `restaurante_id`, `nome`, `descricao`, `preco`, `tipo`, `imagem`, `criado_em`, `atualizado_em`, `categoria`) VALUES
(5, 13, 'Pizza de Calabresa', 'calabresa\r\nceloba\r\ntomate\r\nqueijo\r\nmto', 85.00, 'comida', '69000fe423606.png', '2025-10-28 00:35:48', '2025-10-28 00:35:48', 'comida'),
(6, 13, 'Coca Cola', '2 Litros', 8.00, 'bebida', '690010371a89a.jpeg', '2025-10-28 00:37:11', '2025-10-28 00:37:11', 'comida'),
(7, 13, 'Pizza de Atum', '', 85.00, 'comida', '690010957516a.jpeg', '2025-10-28 00:37:55', '2025-10-28 00:38:45', 'comida'),
(12, 13, 'Coca Cola 2', 'coca 2', 22.00, 'bebida', '6902913e424ae.jpeg', '2025-10-29 22:12:14', '2025-10-29 22:12:14', 'comida');

-- --------------------------------------------------------

--
-- Estrutura para tabela `pedidos`
--

CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `restaurante_id` int(11) NOT NULL,
  `endereco_entrega` varchar(255) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `status` enum('pendente','preparacao','entrega','entregue') DEFAULT 'pendente',
  `endereco` text DEFAULT NULL,
  `forma_pagamento` enum('dinheiro','cartao','pix') DEFAULT 'dinheiro',
  `pago` tinyint(1) DEFAULT 0,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  `tipo_pedido` enum('local','delivery') DEFAULT 'delivery',
  `mesa` varchar(10) DEFAULT NULL,
  `observacoes` text DEFAULT NULL,
  `pagamento` varchar(20) DEFAULT NULL,
  `tipo` varchar(20) DEFAULT NULL,
  `observacao` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `pedidos`
--

INSERT INTO `pedidos` (`id`, `cliente_id`, `restaurante_id`, `endereco_entrega`, `total`, `status`, `endereco`, `forma_pagamento`, `pago`, `criado_em`, `tipo_pedido`, `mesa`, `observacoes`, `pagamento`, `tipo`, `observacao`) VALUES
(1, 29, 13, '', 93.00, 'entregue', '', 'dinheiro', 0, '2025-10-29 20:36:29', 'delivery', 'mesa 10', NULL, 'no_local', 'local', 'sem celoba'),
(2, 29, 13, '', 93.00, '', '', 'dinheiro', 0, '2025-10-29 21:30:13', 'delivery', '11', NULL, 'no_local', 'local', 'muito queijooooo'),
(3, 29, 13, '', 93.00, 'pendente', '', 'dinheiro', 0, '2025-10-29 22:02:08', 'delivery', '14', NULL, 'no_local', 'local', 'com queijo'),
(4, 29, 13, '', 285.00, 'pendente', '', 'dinheiro', 0, '2025-10-29 22:04:32', 'delivery', '15', NULL, 'no_local', 'local', ''),
(5, 29, 13, '', 293.00, 'pendente', '', 'dinheiro', 0, '2025-10-29 22:04:55', 'delivery', '34', NULL, 'no_local', 'local', '3434345'),
(6, 29, 13, '', 170.00, 'pendente', '', 'dinheiro', 0, '2025-10-29 22:05:50', 'delivery', '324234', NULL, 'no_local', 'local', '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `pedido_itens`
--

CREATE TABLE `pedido_itens` (
  `id` int(11) NOT NULL,
  `pedido_id` int(11) NOT NULL,
  `cardapio_id` int(11) NOT NULL,
  `qtd` int(11) NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `observacao` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `pedido_itens`
--

INSERT INTO `pedido_itens` (`id`, `pedido_id`, `cardapio_id`, `qtd`, `preco`, `observacao`) VALUES
(1, 1, 5, 1, 85.00, ''),
(2, 1, 6, 1, 8.00, ''),
(3, 2, 5, 1, 85.00, ''),
(4, 2, 6, 1, 8.00, ''),
(5, 3, 5, 1, 85.00, ''),
(6, 3, 6, 1, 8.00, ''),
(7, 4, 5, 1, 85.00, ''),
(8, 4, 11, 1, 200.00, ''),
(9, 5, 6, 1, 8.00, ''),
(10, 5, 7, 1, 85.00, ''),
(11, 5, 11, 1, 200.00, ''),
(12, 6, 5, 2, 85.00, '');

-- --------------------------------------------------------

--
-- Estrutura para tabela `pratos`
--

CREATE TABLE `pratos` (
  `id` int(11) NOT NULL,
  `restaurante_id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` text DEFAULT NULL,
  `preco` decimal(10,2) NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `nome_proprietario` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `tipo` enum('cliente','restaurante','admin') DEFAULT 'cliente',
  `cpf_cnpj_tipo` enum('CPF','CNPJ') DEFAULT NULL,
  `cpf_cnpj` varchar(18) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `endereco` varchar(255) DEFAULT NULL,
  `descricao` text DEFAULT NULL,
  `cnpj` varchar(20) DEFAULT NULL,
  `cpf` varchar(14) DEFAULT NULL,
  `logotipo` varchar(255) DEFAULT NULL,
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp(),
  `pix_tipo` varchar(20) DEFAULT NULL,
  `pix_chave` varchar(255) DEFAULT NULL,
  `mp_access_token` text DEFAULT NULL,
  `tipo_chave_pix` varchar(20) DEFAULT 'cpf',
  `horario_funcionamento` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`horario_funcionamento`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `nome_proprietario`, `email`, `senha`, `tipo`, `cpf_cnpj_tipo`, `cpf_cnpj`, `telefone`, `endereco`, `descricao`, `cnpj`, `cpf`, `logotipo`, `criado_em`, `pix_tipo`, `pix_chave`, `mp_access_token`, `tipo_chave_pix`, `horario_funcionamento`) VALUES
(13, 'Pizzaria Boa Massa', 'GABRIEL BACCHIEGA DE JESUS', 'pizza@gmail.com', '$2y$10$bmzjKTIBPrS0AHpLn7ccuuP/ceyXJvx5r71TKgpcvP5bIr0BrCeqa', 'restaurante', 'CPF', '41525199838', '14989876573', 'Rubens Rodrigues, 13', 'Fazemos tudo com ótima qualidade e frete grátis para toda cidade. \r\nNossa prioridade é sua experiência e satisfação!', '11111111111111111111', NULL, '690003fba5a08_pepe.jpeg', '2025-10-27 23:44:59', NULL, '41525199838', NULL, 'cpf', '{\"Domingo\":\"08:00 - 18:00\",\"Segunda\":\"Fechado\",\"Terça\":\"Fechado\",\"Quarta\":\"08:00 - 18:00\",\"Quinta\":\"08:00 - 18:00\",\"Sexta\":\"08:00 - 18:00\",\"Sábado\":\"08:00 - 18:00\"}'),
(16, 'Burguer 25', NULL, 'bu@gmail.com', '$2y$10$UgisvNJK2j8dODUliuOUve79mJtxQ05rQEVK9nkj6.2PEZC4b5f5S', 'restaurante', NULL, NULL, '14997573628', 'Chácara Terra Dourada, Lote 13', NULL, '', NULL, '6901376cee796.jpeg', '2025-10-28 01:00:40', NULL, '41525199838', NULL, 'cpf', NULL),
(29, 'GABRIEL BACCHIEGA DE JESUS', NULL, 'gabrielbacchiega37@gmail.com', '$2y$10$tWMrGZkRc9WCW/cjUZ1.OulDgDdIgqBAKpbW6F6nSZ8/SdgHtGJ56', 'cliente', NULL, NULL, '14997573628', 'Chácara Terra Dourada, Lote 13', NULL, '', NULL, '690269cca9323.jpeg', '2025-10-29 19:23:23', NULL, NULL, NULL, 'cpf', NULL);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `cardapio`
--
ALTER TABLE `cardapio`
  ADD PRIMARY KEY (`id`),
  ADD KEY `restaurante_id` (`restaurante_id`);

--
-- Índices de tabela `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cliente_id` (`cliente_id`),
  ADD KEY `restaurante_id` (`restaurante_id`);

--
-- Índices de tabela `pedido_itens`
--
ALTER TABLE `pedido_itens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pedido_id` (`pedido_id`);

--
-- Índices de tabela `pratos`
--
ALTER TABLE `pratos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `restaurante_id` (`restaurante_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `cardapio`
--
ALTER TABLE `cardapio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `pedido_itens`
--
ALTER TABLE `pedido_itens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `pratos`
--
ALTER TABLE `pratos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `cardapio`
--
ALTER TABLE `cardapio`
  ADD CONSTRAINT `cardapio_ibfk_1` FOREIGN KEY (`restaurante_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `pedidos_ibfk_2` FOREIGN KEY (`restaurante_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `pedido_itens`
--
ALTER TABLE `pedido_itens`
  ADD CONSTRAINT `pedido_itens_ibfk_1` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `pratos`
--
ALTER TABLE `pratos`
  ADD CONSTRAINT `pratos_ibfk_1` FOREIGN KEY (`restaurante_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
