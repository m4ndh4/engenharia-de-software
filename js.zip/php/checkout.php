<?php
session_start();

// Pega os parâmetros da URL (GET) ou da sessão
if (isset($_GET['plano']) && isset($_GET['valor'])) {
    $_SESSION['plano'] = $_GET['plano'];
    $_SESSION['valor'] = $_GET['valor'];
}

$plano = $_SESSION['plano'] ?? 'Personalizado';
$valor = $_SESSION['valor'] ?? '0.00';
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Contato sobre planos - CardapiOn</title>
  <link rel="stylesheet" href="../css/checkout.css">
  <style>
    .checkout-container {
      max-width: 500px;
      margin: 80px auto;
      background: #fff;
      padding: 30px;
      border-radius: 14px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.1);
      text-align: center;
    }

    .checkout-container h2 {
      margin-bottom: 15px;
    }

    .checkout-container p {
      color: #555;
      line-height: 1.5;
    }

    .btn-whatsapp {
      display: inline-block;
      background: #25d366;
      color: #fff;
      padding: 14px 22px;
      border-radius: 10px;
      font-weight: bold;
      text-decoration: none;
      margin-top: 20px;
      transition: 0.3s;
    }

    .btn-whatsapp:hover {
      background: #1ebe5d;
    }

    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #fff;
      padding: 15px 30px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }

    header .logo strong {
      font-size: 20px;
      color: #333;
    }

    .nav a {
      margin-right: 15px;
      color: #333;
      text-decoration: none;
    }

    .nav a:hover {
      color: #007bff;
    }

    .btn {
      background: #007bff;
      color: #fff;
      padding: 8px 14px;
      border-radius: 8px;
      text-decoration: none;
    }

    .btn.secondary {
      background: #666;
    }
  </style>
</head>
<body>


<div class="checkout-container">
  <h2>Entre em Contato</h2>
  <p>Olá! 👋</p>
  <p>Se você é dono de restaurante e quer modernizar o atendimento, clique no botão abaixo para conversar comigo no WhatsApp.</p>
  <p>Falaremos sobre os <strong>planos personalizados</strong> para o seu negócio e como o <strong>CardapiOn</strong> pode ajudar!</p>

  <?php
    $mensagem = urlencode("Olá! Tenho interesse em saber mais sobre os planos do CardapiOn.");
    $whatsapp = "5514997573628"; 
  ?>
  
  <a href="https://wa.me/<?= $whatsapp ?>?text=<?= $mensagem ?>" target="_blank" class="btn-whatsapp">
    💬 Falar no WhatsApp
  </a>
</div>

</body>
</html>
