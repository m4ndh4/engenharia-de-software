<?php
session_start();
include 'conexao.php';

if(!isset($_SESSION['usuario_id'])){
    exit("⚠️ Você precisa estar logado.");
}

$usuario_id = $_SESSION['usuario_id'];

// Apaga usuário
$stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
$ok = $stmt->execute([$usuario_id]);

if ($ok) {
    session_destroy();
    echo "OK! Conta excluída com sucesso.";
} else {
    echo "❌ Erro ao excluir conta.";
}
