<?php
session_start();
include 'conexao.php';

if (!isset($_SESSION['usuario_id'])) {
    exit("⚠️ Você precisa estar logado.");
}

$usuario_id = $_SESSION['usuario_id'];

// Busca usuário atual
$stmt = $conn->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->execute([$usuario_id]);
$usuario = $stmt->fetch();

if (!$usuario) {
    exit("❌ Usuário não encontrado.");
}

// Campos básicos
$nome            = $_POST['nome']       ?? $usuario['nome'];
$email           = $_POST['email']      ?? $usuario['email'];
$telefone        = $_POST['telefone']   ?? $usuario['telefone'];
$endereco        = $_POST['endereco']   ?? $usuario['endereco'];
$logotipo        = $usuario['logotipo']; // mantém o atual se não trocar
$cpf_cnpj        = $_POST['cpf_cnpj']   ?? $usuario['cpf_cnpj'] ?? null;
$cpf_cnpj_tipo   = $_POST['cpf_cnpj_tipo'] ?? $usuario['cpf_cnpj_tipo'] ?? null;
$nome_proprietario = $_POST['nome_proprietario'] ?? $usuario['nome_proprietario'] ?? null;

// Campos de pagamento
$pix_chave       = $_POST['pix_chave'] ?? $usuario['pix_chave'] ?? null;
$pix_tipo        = $_POST['pix_tipo']  ?? $usuario['pix_tipo'] ?? null;

// Campo de descrição (se existir)
$descricao       = $_POST['descricao'] ?? $usuario['descricao'] ?? null;

// Horário de funcionamento (JSON)
if (isset($_POST['horario_funcionamento']) && is_array($_POST['horario_funcionamento'])) {
    $horario_funcionamento = json_encode($_POST['horario_funcionamento'], JSON_UNESCAPED_UNICODE);
} else {
    $horario_funcionamento = $usuario['horario_funcionamento'] ?? null;
}

// Upload do logotipo (se enviado)
if (!empty($_FILES['logotipo']['name']) && $_FILES['logotipo']['error'] === 0) {
    $targetDir = "../uploads/";
    if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

    $ext = pathinfo($_FILES['logotipo']['name'], PATHINFO_EXTENSION);
    $filename = uniqid().".".$ext;
    $targetFile = $targetDir.$filename;

    if (move_uploaded_file($_FILES['logotipo']['tmp_name'], $targetFile)) {
        // Remove antigo
        if (!empty($usuario['logotipo']) && file_exists($targetDir.$usuario['logotipo'])) {
            unlink($targetDir.$usuario['logotipo']);
        }
        $logotipo = $filename;
    }
}

// Monta parâmetros
$params = [
    ':nome' => $nome,
    ':email' => $email,
    ':telefone' => $telefone,
    ':endereco' => $endereco,
    ':logotipo' => $logotipo,
    ':cpf_cnpj' => $cpf_cnpj,
    ':cpf_cnpj_tipo' => $cpf_cnpj_tipo,
    ':descricao' => $descricao,
    ':nome_proprietario' => $nome_proprietario,
    ':id' => $usuario_id
];

// SQL base
if ($usuario['tipo'] === 'restaurante') {
    $sql = "UPDATE usuarios 
            SET nome = :nome, 
                email = :email, 
                telefone = :telefone, 
                endereco = :endereco, 
                cpf_cnpj = :cpf_cnpj,
                cpf_cnpj_tipo = :cpf_cnpj_tipo,
                nome_proprietario = :nome_proprietario,
                logotipo = :logotipo,
                descricao = :descricao,
                pix_chave = :pix_chave,
                pix_tipo = :pix_tipo,
                horario_funcionamento = :horario_funcionamento
            WHERE id = :id";

    $params[':pix_chave'] = $pix_chave;
    $params[':pix_tipo'] = $pix_tipo;
    $params[':horario_funcionamento'] = $horario_funcionamento;
} else {
    $sql = "UPDATE usuarios 
            SET nome = :nome, 
                email = :email, 
                telefone = :telefone, 
                endereco = :endereco, 
                cpf_cnpj = :cpf_cnpj,
                cpf_cnpj_tipo = :cpf_cnpj_tipo,
                nome_proprietario = :nome_proprietario,
                logotipo = :logotipo,
                descricao = :descricao
            WHERE id = :id";
}

// Executa
$stmt = $conn->prepare($sql);
$ok = $stmt->execute($params);

if ($ok) {
    $_SESSION['usuario_nome'] = $nome;
    echo "OK! Dados salvos com sucesso.";
} else {
    $err = $stmt->errorInfo();
    echo "❌ Erro ao salvar dados. MySQL: " . ($err[2] ?? 'Desconhecido');
}
