<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] !== 'cliente') {
    header("Location: login.php");
    exit;
}

include 'conexao.php';

// Busca restaurantes
$stmt = $conn->query("SELECT id, nome, logotipo FROM usuarios WHERE tipo = 'restaurante'");
$restaurantes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CardapiOn — Restaurantes</title>
<link rel="stylesheet" href="../css/cliente.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link href='https://cdn.boxicons.com/3.0.3/fonts/basic/boxicons.min.css' rel='stylesheet'>
</head>
<body>

<header class="topo">
  <div class="titulo">
    <div>
      <h1>CardapiOn</h1>
      <p>Encontre seu restaurante favorito</p>
    </div>
    <a href="index.php" class="ativo">
      <i class="fa-solid fa-home"></i>
      Inicio
    </a>
    <input type="text" id="buscaRestaurante" placeholder="Buscar restaurante...">
  </div>
</header>

<section class="container">
  <h2>Restaurantes disponíveis </h2>

  <div class="restaurantes" id="listaRestaurantes">
    <?php foreach ($restaurantes as $r): ?>
      <div class="card">
        <a href="menu.php?id=<?= $r['id'] ?>">
          <div class="imagem">
            <?php if ($r['logotipo']): ?>
              <img src="../uploads/<?= htmlspecialchars($r['logotipo']) ?>" alt="Logo <?= htmlspecialchars($r['nome']) ?>">
            <?php else: ?>
              <img src="../img/no-logo.png" alt="Sem logotipo">
            <?php endif; ?>
          </div>
          <div class="info">
            <h3><?= htmlspecialchars($r['nome']) ?></h3>
            <p>Entrega rápida • Frete grátis</p>
          </div>
        </a>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<footer class="rodape">
  
</footer>

<script>
// ====== BUSCA ======
document.getElementById('buscaRestaurante').addEventListener('input', function() {
  const termo = this.value.toLowerCase();
  const cards = document.querySelectorAll('.card');
  cards.forEach(c => {
    const nome = c.querySelector('h3').textContent.toLowerCase();
    c.style.display = nome.includes(termo) ? '' : 'none';
  });
});

// ====== CARROSSEL AUTOMÁTICO ======
</script>

</body>
</html>
