<?php
session_start();
if(isset($_SESSION['usuario_id'])){
    header('Location: cliente.php');
    exit;
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<link rel="stylesheet" href="../css/cadastro.css">
<title>Cadastro — CardapiOn</title>
</head>
<body>

<main style="max-width:500px;margin:80px auto;padding:20px;border:1px solid #ccc;border-radius:12px;">
    <h2>Criar Conta</h2>
    <form id="signupForm" enctype="multipart/form-data">
        <div class="form-row">
            <label for="name">Nome</label>
            <input id="name" name="name" type="text" required />
        </div>

        <div class="form-row">
            <label for="email">E-mail</label>
            <input id="email" name="email" type="email" required />
        </div>

        <div class="form-row">
            <label for="password">Senha</label>
            <input id="password" name="password" type="password" required />
        </div>

        <div class="form-row">
            <label for="tipo">Tipo de conta</label>
            <select id="tipo" name="tipo" required>
                <option value="cliente">Cliente</option>
                <option value="restaurante">Restaurante</option>
            </select>
        </div>

        <div class="form-row">
            <label for="telefone">Telefone</label>
            <input id="telefone" name="telefone" type="text" />
        </div>

        <div class="form-row">
            <label for="endereco">Endereço</label>
            <input id="endereco" name="endereco" type="text" />
        </div>

        <!-- CAMPOS EXCLUSIVOS DE RESTAURANTE -->
        <div id="dadosRestaurante" style="display:none">
            <div class="form-row">
                <label for="nome_proprietario">Nome do Proprietário</label>
                <input id="nome_proprietario" name="nome_proprietario" type="text" />
            </div>

            <div class="form-row">
                <label for="cpf">CPF (caso não tenha CNPJ)</label>
                <input id="cpf" name="cpf" type="text" maxlength="14" placeholder="000.000.000-00" />
            </div>

            <div class="form-row">
                <label for="cnpj">CNPJ</label>
                <input id="cnpj" name="cnpj" type="text"/>
            </div>

            <div class="form-row">
                <label for="pix">Chave PIX</label>
                <input id="pix" name="pix" type="text" placeholder="CPF, CNPJ, e-mail ou chave aleatória" />
                <small id="pixStatus" style="color:gray;display:none"></small>
            </div>

            <div class="form-row">
                <label for="logotipo">Logotipo</label>
                <input id="logotipo" name="logotipo" type="file" accept="image/*" />
            </div>
        </div>
        <!-- FIM CAMPOS RESTAURANTE -->

        <div style="margin-top:12px">
            <button type="submit" class="btn">Criar Conta</button>
        </div>
    </form>

    <p style="margin-top:12px">
        Já tem conta? <a href="login.php">Entrar aqui</a>
    </p>
</main>

<script>
const tipoSelect = document.getElementById('tipo');
const dadosRestaurante = document.getElementById('dadosRestaurante');
const pixInput = document.getElementById('pix');
const pixStatus = document.getElementById('pixStatus');

// Alterna exibição dos campos de restaurante
tipoSelect.addEventListener('change', function() {
    dadosRestaurante.style.display = (this.value === 'restaurante') ? 'block' : 'none';
});

// ======== Validação via API PIX (mock) ========
pixInput?.addEventListener('blur', () => {
    const chave = pixInput.value.trim();
    const nome = document.getElementById('nome_proprietario').value.trim();

    if(chave !== '' && nome !== ''){
        pixStatus.style.display = 'block';
        pixStatus.style.color = 'gray';
        pixStatus.textContent = 'Verificando titular da chave PIX...';

        fetch('verificar_pix.php?chave=' + encodeURIComponent(chave) + '&nome=' + encodeURIComponent(nome))
        .then(r => r.json())
        .then(data => {
            if(data.verificado){
                pixStatus.style.color = 'green';
                pixStatus.textContent = 'Chave PIX pertence ao titular informado.';
            } else {
                pixStatus.style.color = 'red';
                pixStatus.textContent = 'Chave PIX não confere com o nome informado.';
            }
        })
        .catch(() => {
            pixStatus.style.color = 'red';
            pixStatus.textContent = 'Erro ao consultar PIX.';
        });
    }
});

// ======== Envio do formulário ========
document.getElementById('signupForm').addEventListener('submit', function(e){
    e.preventDefault();
    const form = new FormData(this);
    fetch('auth.php?action=signup', { method:'POST', body: form })
    .then(r=>r.text())
    .then(txt=>{
        alert(txt);
        if(txt.includes('OK')) window.location.href='cliente.php';
    })
    .catch(()=> alert('Erro ao comunicar com servidor.'));
});
</script>

</body>
</html>
