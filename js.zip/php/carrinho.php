<?php
session_start();
if(!isset($_SESSION['carrinho'])) $_SESSION['carrinho'] = [];

if($_SERVER['REQUEST_METHOD']==='POST'){
    $item = [
        'id'    => $_POST['id'],
        'nome'  => $_POST['nome'],
        'preco' => $_POST['preco'],
        'qtd'   => $_POST['qtd'],
        'obs'   => $_POST['obs'],
    ];
    $_SESSION['carrinho'][] = $item;
}

$carrinho = $_SESSION['carrinho'];
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>Seu Carrinho</title>
  <link rel="stylesheet" href="../css/cliente.css">
</head>
<body>
<h2>Carrinho</h2>
<a href="javascript:history.back()">← Continuar comprando</a>

<?php if(empty($carrinho)): ?>
  <p>Seu carrinho está vazio.</p>
<?php else: ?>
  <table border="1" cellpadding="5">
    <tr>
      <th>Produto</th><th>Qtd</th><th>Preço</th><th>Obs</th><th>Total</th>
    </tr>
    <?php $total=0; foreach($carrinho as $c): 
        $linha = $c['preco']*$c['qtd'];
        $total += $linha;
    ?>
    <tr>
      <td><?= htmlspecialchars($c['nome']) ?></td>
      <td><?= $c['qtd'] ?></td>
      <td>R$ <?= number_format($c['preco'],2,',','.') ?></td>
      <td><?= htmlspecialchars($c['obs']) ?></td>
      <td>R$ <?= number_format($linha,2,',','.') ?></td>
    </tr>
    <?php endforeach; ?>
    <tr>
      <td colspan="4"><strong>Total:</strong></td>
      <td><strong>R$ <?= number_format($total,2,',','.') ?></strong></td>
    </tr>
  </table>

  <form action="finalizar_pedido.php" method="post">
    <button type="submit">Finalizar Pedido</button>
  </form>
<?php endif; ?>
</body>
</html>
