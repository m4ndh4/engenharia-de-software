<?php
session_start();
include 'conexao.php';


// index.php - Landing page com login/cadastro de clientes e restaurantes
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <link rel="stylesheet" href="../css/index.css">
  <title>CardapiOn — Home</title>
</head>
<body>

<header>
  <div class="logo">
    <div>
      <strong>CardapiOn</strong><br>
      <small class="small">Pedidos e gestão</small>
    </div>
  </div>

  <nav class="nav" aria-label="main navigation">
    <a href="#">Início</a>
    <a href="#features">Funcionalidades</a>
    <a href="#pricing">Planos</a>
    <a href="cliente.php">Restaurantes</a>
  </nav>


<div style=" display:flex;">
  
   <?php if (isset($_SESSION['usuario_id'])): ?>
     <!-- Se estiver logado -->
     <li><a href="Perfil.php" class="btn">Perfil</a></li>
   <?php else: ?>
     <!-- Se não estiver logado -->
     <li><a href="Login.php" class="btn secondary" >Entrar</a></li>
   <?php endif; ?>

</div>

</header>

<main>
  <section class="hero" role="region" aria-label="hero">
    <div class="hero-left">
      <h1>Cardápio digital para seu restaurante</h1>
      <p>Plataforma para gerenciamento de pedidos em estabelecimentos — cardápios digitais, acompanhamento em tempo real e controle de mesas.</p>

      <div class="feature-cards" role="list">
        <div class="card" role="listitem"><strong>Cardápios rápidos</strong><div class="small">QR + Web</div></div>
        <div class="card" role="listitem"><strong>Pedidos em tempo real</strong><div class="small">Cozinha & admin</div></div>
      </div>
    </div>

    <div class="hero-right">
      <div class="hero-illustration">
        <img src="../img/qrcode.png">
      </div>
    </div>
  </section>

  <section id="features" class="features" aria-label="funcionalidades">
    <h2>O que você consegue</h2>
    <div class="feature-list" role="list" style="margin-left: 200px;">
      <div class="feature-item"><strong>Menus personalizáveis</strong><p class="small">Monte categorias, fotos e descrições.</p></div>
      <div class="feature-item"><strong>Gestão de mesas</strong><p class="small">Receba pedidos por mesa e acompanhe a preparação.</p></div>
    </div>
  </section>

<?php
$logado = isset($_SESSION['usuario_id']); // true se o usuário estiver logado
?>
<a href="checkout.php" style="text-decoration:none; color:inherit;">
  <section id="pricing" class="pricing" aria-label="planos" style="cursor:pointer; padding:40px 0;">
    <div class="pricing-grid" style="display:flex; align-items:center; justify-content:center; gap:40px; max-width:1000px; margin:auto; background:#fff; border-radius:16px; box-shadow:0 3px 10px rgba(0,0,0,0.1); transition:0.3s;">
      
      <!-- Imagem à esquerda -->
      <div style="flex:1; display:flex; justify-content:center;">
        <img src="../img/contato-removebg-preview.png" alt="Entre em contato" style="width:260px; max-width:100%; height:auto;">
      </div>

      <!-- Texto à direita -->
      <div class="price" style="flex:1; transition:0.3s; padding:20px;">
        <h2 style="margin-bottom:10px;">Planos</h2>
        <h3>Seja parceiro</h3>
        <p class="small">Restaurantes, modernizem seu atendimento!</p>
        <p><strong>💼 Planos personalizados</strong></p>
        <ul class="small">
          <li>Gestão completa de pedidos</li>
          <li>Suporte técnico</li>
          <li>Integração com PIX e Mercado Pago</li>
        </ul>
          </div>

    </div>
  </section>
</a>

</a>






</main>

<footer id="contact">
  <div style="max-width:1100px;margin:0 auto;display:flex;justify-content:space-between;align-items:center">
    <div>
      <strong>CardapiOn</strong><br>
      <span class="small">© <?= date('Y') ?> — Feito por CardapiOn</span>
    </div>
    <div class="small">Contato: CardapiOn@gmail.com</div>
  </div>
</footer>

</body>
</html>
