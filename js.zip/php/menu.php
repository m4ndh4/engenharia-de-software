  <?php
  session_start();
  include 'conexao.php';

  if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] !== 'cliente') {
      header("Location: login.php");
      exit;
  }

  $restaurante_id = $_GET['id'] ?? null;
  if (!$restaurante_id) {
      header("Location: cliente.php");
      exit;
  }

  // Informações do restaurante
  $stmt = $conn->prepare("SELECT nome, telefone, endereco, descricao, logotipo, pix_chave, horario_funcionamento FROM usuarios WHERE id = :id AND tipo = 'restaurante'");
  $stmt->execute([':id' => $restaurante_id]);
  $restaurante = $stmt->fetch(PDO::FETCH_ASSOC);
  if (!$restaurante) {
      echo "Restaurante não encontrado.";
      exit;
  }

  // Cardápio
  $stmt = $conn->prepare("SELECT id, nome, descricao, preco, imagem, categoria FROM cardapio WHERE restaurante_id = :id");
  $stmt->execute([':id' => $restaurante_id]);
  $produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);

  // Horários
  $horarios = json_decode($restaurante['horario_funcionamento'] ?? '{}', true) ?: [];
  ?>
  <!doctype html>
  <html lang="pt-BR">
  <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($restaurante['nome']) ?> — Cardápio</title>
  <link rel="stylesheet" href="../css/menu.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  </head>
  <body>

  <header class="topo">
    <?php if ($restaurante['logotipo']): ?>
      <div class="restaurante-header">
        <!-- PARTE 1 — LOGO E NOME -->
        <div class="restaurante-header-esquerda">
          <img class="logo" src="../uploads/<?= htmlspecialchars($restaurante['logotipo']) ?>" alt="Logo <?= htmlspecialchars($restaurante['nome']) ?>">
          <h1><?= htmlspecialchars($restaurante['nome']) ?></h1>
        </div>

        <!-- PARTE 2 — INFORMAÇÕES -->
        <div class="restaurante-info">
          <div style="display: flex; gap: 10px;">
            <p><strong><i class="fa-solid fa-phone"></i> Telefone:</strong> <?= htmlspecialchars($restaurante['telefone']) ?></p>
            <p><strong><i class="fa-solid fa-location-dot"></i> Endereço:</strong> <?= htmlspecialchars($restaurante['endereco']) ?></p>
            <br>
          </div>
          <div style="color: green; padding: 5px;">
            <h4>
              Aberto
            </h4>
          </div>
        </div>
      </div>
    <?php endif; ?>
  </header>


  <div class="container">
    <aside class="carrinho">
      <h2> Seu Pedido</h2>
      <div id="itens"></div>

      <div id="areaOpcoes" style="display:none;">
        <div class="opcao-entrega">
          <label>Tipo de pedido:</label>
          <select id="tipoPedido" onchange="alternarEntrega()">
            <option value="">Selecione</option>
            <option value="entrega">Entrega</option>
            <option value="local">No local</option>
          </select>
        </div>

        <div class="endereco-box" id="boxEndereco">
          <label>Endereço de entrega:</label>
          <br>
          <textarea id="endereco" placeholder="Rua, nº, bairro..."></textarea>
          <br>
          <label>Observações:</label>
          <br>
          <textarea id="obsEntrega" placeholder="Ex: sem cebola, aniversário..."></textarea>
          <br>
        </div>

        <div class="mesa-box" id="boxMesa" style="">
          <label for="mesa">Número da mesa:</label>
          <br>
          <input type="text" id="mesa" placeholder="Ex: Mesa 7">
          <br>
          <label for="obsMesa">Observações:</label>
          <br>
          <textarea id="obsMesa" placeholder="Ex: sem cebola, aniversário..."></textarea>
        </div>
      </div>

      <div class="total">
        Total: R$ <span id="total">0,00</span>
      </div>

      <div class="actions">
        <button class="finalizar" onclick="abrirPagamento()" data-bs-toggle="modal" data-bs-target="#modalPagamento">Finalizar Pedido</button>
        <button class="limpar" onclick="limparCarrinho()">Limpar Carrinho</button>
      </div>
    </aside>

    <main class="cardapio-area">
      

      <div class="filtro-categoria">
        <button class="active" onclick="filtrarCategoria('todos')">Todos</button>
        <button onclick="filtrarCategoria('comida')">Comida</button>
        <button onclick="filtrarCategoria('bebida')">Bebida</button>
      </div>

      <div class="cardapio" id="cardapio">
        <?php foreach ($produtos as $item): ?>
          <div class="produto" data-categoria="<?= htmlspecialchars($item['categoria'] ?? 'comida') ?>" onclick="toggleDetalhes(this)">
            <?php if ($item['imagem']): ?>
              <img src="../uploads/<?= htmlspecialchars($item['imagem']) ?>" alt="<?= htmlspecialchars($item['nome']) ?>">
            <?php endif; ?>
            <h3><?= htmlspecialchars($item['nome']) ?></h3>
            <span class="preco">R$ <?= number_format($item['preco'],2,',','.') ?></span>
            <p class="descricao-detalhe"><?= htmlspecialchars($item['descricao']) ?></p>
            <button onclick="event.stopPropagation(); adicionarCarrinho(<?= $item['id'] ?>, '<?= htmlspecialchars($item['nome']) ?>', <?= $item['preco'] ?>)">Adicionar</button>
          </div>
        <?php endforeach; ?>
      </div>
    </main>
  </div>

  <!-- Modal de Pagamento / Confirmação -->
  <div class="modal-bg modal" id="modalPagamento" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" style="background-color: #fff; width: 400px; padding: 10px; margin-left: 20px; border-radius: 10px; box-shadow: 0 2px 6px rgba(0,0,0,0.1);">
    <div class="">
      <h3 id="tituloPagamento">Forma de Pagamento</h3>
      <div id="resumoPedido" style="max-height:150px; overflow-y:auto; margin:10px 0; border:1px solid #ddd; padding:8px; border-radius:8px;"></div>

      <div id="areaPagamentoOpcoes">
        ...
      </div>
      <div id="areaPagamentoOpcoes">
        <select id="formaPagamento">
          <option value="">Selecione</option>
          <option value="pix">PIX</option>
          <option value="debito">Débito</option>
          <option value="credito">Crédito</option>
        </select>
        <div id="areaPix" style="display:none;">
          <p>Escaneie o QR Code:</p>
          <img id="qrcodePix" src="" alt="QR Code PIX">
        </div>
        <div id="areaCartao" style="display:none;">
          <p>💳 Pagamento será feito na entrega via maquininha.</p>
        </div>
      </div>
      <button class="btn-confirmar" onclick="confirmarPedido()" >
        <i class="fa-solid fa-check"></i> 
        Confirmar Pedido
      </button>
      <button class="btn-cancelar" onclick="fecharPagamento()"><i class="fa-solid fa-x"></i>Cancelar</button>
    </div>
  </div>

  <script>
    function exibirResumoPedido() {
  const resumo = document.getElementById("resumoPedido");
  resumo.innerHTML = "<strong>Itens do Pedido:</strong><br>";
  let total = 0;

  for (let id in carrinho) {
    const item = carrinho[id];
    const subtotal = item.qtd * item.preco;
    total += subtotal;
    resumo.innerHTML += `
      <div style="display:flex; justify-content:space-between; margin:5px 0;">
        <span>${item.nome} (${item.qtd}x)</span>
        <span>R$ ${subtotal.toFixed(2).replace('.', ',')}</span>
      </div>
    `;
  }

  resumo.innerHTML += `<hr><strong>Total: R$ ${total.toFixed(2).replace('.', ',')}</strong>`;
}



  let carrinho = JSON.parse(sessionStorage.getItem("carrinho")) || {};
  const pixChaveRestaurante = "<?= htmlspecialchars($restaurante['pix_chave']) ?>";
  const restauranteId = <?= $restaurante_id ?>;

  function adicionarCarrinho(id,nome,preco){
    if(!carrinho[id]) carrinho[id]={id,nome,preco,qtd:1,obs:""};
    else carrinho[id].qtd++;
    salvarCarrinho(); renderCarrinho();
    document.getElementById("areaOpcoes").style.display="block";
  }

  function renderCarrinho(){
    const itensDiv=document.getElementById("itens"); itensDiv.innerHTML="";
    let total=0;
    for(let id in carrinho){
      let item=carrinho[id]; total+=item.qtd*item.preco;
      itensDiv.innerHTML+=`<div class="item-carrinho"><strong>${item.nome}</strong><br><span>R$ ${(item.preco*item.qtd).toFixed(2).replace('.',',')}</span><br><div class="qtd-box"><button onclick="alterarQtd(${id},-1)">-</button><span>${item.qtd}</span><button onclick="alterarQtd(${id},1)">+</button></div></div>`;
    }
    document.getElementById("total").textContent=total.toFixed(2).replace('.',',');
  }

  function alterarQtd(id,delta){
    if(carrinho[id]){
      carrinho[id].qtd+=delta;
      if(carrinho[id].qtd<=0) delete carrinho[id];
      salvarCarrinho(); renderCarrinho();
    }
    if(Object.keys(carrinho).length===0) document.getElementById("areaOpcoes").style.display="none";
  }

  function salvarCarrinho(){ sessionStorage.setItem("carrinho",JSON.stringify(carrinho)); }
  function limparCarrinho(){ carrinho={}; sessionStorage.removeItem("carrinho"); renderCarrinho(); document.getElementById("areaOpcoes").style.display="none"; }

  function alternarEntrega(){
    const tipo=document.getElementById("tipoPedido").value;
    document.getElementById("boxEndereco").style.display=tipo==='entrega'?'block':'none';
    document.getElementById("boxMesa").style.display=tipo==='local'?'block':'none';
  }

  function abrirPagamento(){
    if(Object.keys(carrinho).length===0) return alert("Seu carrinho está vazio!");

    const tipo = document.getElementById("tipoPedido").value;

    if(!tipo) return alert("Selecione o tipo de pedido.");

    const titulo=document.getElementById("tituloPagamento");
    const opcoes=document.getElementById("areaPagamentoOpcoes");

    if(tipo==='local'){
      titulo.textContent="Confirmar Pedido"; opcoes.style.display="none"; 
      }
    else { 
      titulo.textContent="Forma de Pagamento"; opcoes.style.display="block"; 
    }

     exibirResumoPedido()
    document.getElementById("modalPagamento").style.display="flex";
  }

  function fecharPagamento(){
    document.getElementById("modalPagamento").style.display="none";
    document.getElementById("areaPix").style.display="none";
    document.getElementById("areaCartao").style.display="none";
  }

  function filtrarCategoria(categoria){
    const produtos=document.querySelectorAll(".produto");
    document.querySelectorAll(".filtro-categoria button").forEach(b=>b.classList.remove("active"));
    event.target.classList.add("active");
    produtos.forEach(p=>{p.style.display=(categoria==='todos'||p.dataset.categoria===categoria)?'block':'none';});
  }

  function toggleDetalhes(el){ el.classList.toggle("expanded"); }

  function confirmarPedido(){
    const tipo=document.getElementById("tipoPedido").value;
    const endereco=document.getElementById("endereco").value.trim();
    const mesa=document.getElementById("mesa").value.trim();
    const obsMesa=document.getElementById("obsMesa").value.trim();
    const forma=tipo==='local'?'no_local':document.getElementById("formaPagamento").value;

    if(tipo==='entrega' && !forma) return alert("Selecione a forma de pagamento.");
    if(tipo==='entrega' && !endereco) return alert("Informe o endereço.");
    if(tipo==='local' && !mesa) return alert("Informe o número da mesa.");

    fetch("finalizar_pedido.php",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({carrinho,tipoPedido:tipo,endereco,mesa,obsMesa,pagamento:forma,restaurante_id:restauranteId})
    })
    .then(res=>res.text())
    .then(html=>{
      sessionStorage.removeItem("carrinho");
      // Redireciona para cliente.php após confirmação
      window.location.href = "cliente.php";
    })
    .catch(err=>alert("Erro ao finalizar pedido: "+err));
  }

  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>

  </body>
  </html>
