<?php
session_start();
include 'conexao.php';

$restaurante_id = $_GET['id'] ?? 0;
$stmt = $conn->prepare("SELECT * FROM cardapio WHERE restaurante_id=?");
$stmt->execute([$restaurante_id]);
$pratos = $stmt->fetchAll();
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <title>Cardápio</title>
  <link rel="stylesheet" href="../css/cliente.css">
</head>
<body>
<h2>Cardápio</h2>
<a href="restaurantes.php">← Voltar</a>
<div class="grid-pratos">
<?php foreach($pratos as $p): ?>
  <div class="prato-card">
    <?php if($p['imagem']): ?>
      <img src="../uploads/<?= $p['imagem'] ?>" alt="<?= $p['nome'] ?>" width="120">
    <?php endif; ?>
    <h3><?= htmlspecialchars($p['nome']) ?></h3>
    <p><?= htmlspecialchars($p['descricao']) ?></p>
    <p><strong>R$ <?= number_format($p['preco'],2,',','.') ?></strong></p>

    <form action="carrinho.php" method="post">
      <input type="hidden" name="id" value="<?= $p['id'] ?>">
      <input type="hidden" name="nome" value="<?= htmlspecialchars($p['nome']) ?>">
      <input type="hidden" name="preco" value="<?= $p['preco'] ?>">

      <label>Qtd:</label>
      <input type="number" name="qtd" value="1" min="1">

      <label>Obs:</label>
      <input type="text" name="obs" placeholder="Ex: sem cebola">

      <button type="submit">Adicionar ao carrinho</button>
    </form>
  </div>
<?php endforeach; ?>
</div>
</body>
</html>
